/* Area:	ffi_call
   Purpose:	Check return value complex, with many arguments
   Limitations:	none.
   PR:		none.
   Originator:	<vogt@linux.vnet.ibm.com>.  */

/* { dg-do run } */

#include "complex_defs_double.inc"
#include "many_complex.inc"
